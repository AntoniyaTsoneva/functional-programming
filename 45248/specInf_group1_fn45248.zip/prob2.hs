bins f z = [ f a | a <- newNumber]
    where newNumber = 


